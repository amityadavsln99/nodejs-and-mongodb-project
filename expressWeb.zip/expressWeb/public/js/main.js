const cityName = document.getElementById('cityName');
const submitBtn = document.getElementById('submitBtn');
const city_name = document.getElementById('city_name');

const getInfo = async (event) =>{
    event.preventDefault();
    let cityval = cityName.value;
    if(cityval === ""){
        city_name.innerText = `Plz write the name before search`;
    }else{
        try{
            let url = `http://api.openweathermap.org/data/2.5/weather?q=${cityName}&units=metric&appid=b14425a6554d189a2dc18a8e7d7263`;
            const respone = await fetch(url);
            const data = await respone.json();
            console.log(data);
        }catch{
            city_name.innerText = `Plz enter the city name properly`;
        }
    }
}
submitBtn.addEventListener('click', getInfo);